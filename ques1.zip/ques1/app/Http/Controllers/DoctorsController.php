<?php

namespace App\Http\Controllers;

use App\Models\Doctor;
use Illuminate\Http\Request;



class DoctorsController extends Controller

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['doctors'] = Doctor::orderBy('id','desc')->paginate(5);
        return view('doctors.index',$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('doctors.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([

            'doctor_name'=>'required',
            'doctor_image'=>'required|image|mimes:jpg,png,jpeg,gif,svg|max:2048',
            'phone_number'=>'required',
            'appointment_fee'=>'required',

    ]);

    $path = $request->file('doctors_image')->store('public/assets/images');
    $doctor = new Doctor;
    $doctor->doctor_name = $request->doctor_name;
    $doctor->doctor_image = $path;
    $doctor->phone_number = $request->phone_number;
    $doctor->appointment_fee = $request->appointment_fee;
    $doctor->save();

    return redirect()->route('posts.index')->with('success','Post has been created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Doctor  $doctor
     * @return \Illuminate\Http\Response
     */
    public function show(Doctor $doctor)
    {
        return view('doctors.show',compact('doctors'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Doctor  $doctor
     * @return \Illuminate\Http\Response
     */
    public function edit(Doctor $doctor)
    {
        return view('doctors.edit',compact('doctors'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Doctor  $doctor
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Doctor $doctor)
    {
        $request->validate([

            'doctor_name'=>'required',
            'phone_number'=>'required',
            'appointment_fee'=>'required',
    ]);

    $doctor = Doctor::find($id);

    if($request->hasFile('doctor_image'))
    {
        $request->validate([

                'image'=>'required|image|mimes:jpg,png,jpeg,gif,svg|max:2048',
        ]);

        $path = $request->file('image')->store('public/assets/images');
        $doctor->image = $path;
    }

    $doctor->doctor_name = $request->doctor_name;
    $doctor->phone_number = $request->phone_number;
    $doctor->save();

    return redirect()->route('posts.index')->with('success','Post updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Doctor  $doctor
     * @return \Illuminate\Http\Response
     */
    public function destroy(Doctor $doctor)
    
        $doctor->delete();
        return redirect()->route('doctors.index')->with('success','Doctor record has been deleted successfully');
    