<div class="row">
	<div class="col-lg-12 margin-tb">
		<div class="pull-left">
			<h2>All Doctors</h2>
		</div>

	</div>
	<div class="pull-left mb-2">
		<a href="{{ route('doctors.create')}}" class="btn btn-success">Create New Doctor</a>
	</div>
</div>

<br>
@if($message=Session::get('success'))
<div class="alert alert-success">
	<p>{{$message}}</p>
</div>
@endif

@foreach($doctor as $doctors)

<div class="card-group">
	<div class="container py-5">
		<div class="row mt-4">
			<div class="col-md-3">
				<div class="card">
					<img src="{{ Storage::url($doctor->doctor_image)}}" class="card-img-top" height="75" width="75" alt="">
					<div class="card-body">
						<h5 class="card-title">{{$post->title}}</h5>
						<p class="card-text">{{$post->description}}</p>
					</div>
					<div class="card-footer">
						<form action="{{route('posts.destroy',$post->id)}}" method="post">
						<a href="{{route('posts.edit',$post->id)}}" class="btn btn-primary">Edit</a>
						@csrf
						@method('DELETE')
						<button type="submit" class="btn btn-danger">Delete</button>	
						</form>
					</div>
				</div>
			</div>
			@endforeach
		</div>
	</div>
</div>